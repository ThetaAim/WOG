from app import start_play
from app import welcome
# welcome()
start_play()
